/*************************************************************/
/********************* 12864??????,???12864.c *******/
/*************************************************************/
#include <reg52.H>
#define uchar unsigned char
#define uint  unsigned int

sbit LCD_RST = P2^5;			//??12864??
sbit LCD_E = P2^4;
sbit LCD_RW = P2^3;
sbit LCD_RS = P2^2;
sbit LCD_CS2 = P2^1;
sbit LCD_CS1 = P2^0;
#define  Data_Port P0     //??12864???,P0??12864???

// ???????16X16     ??,??,???,C51???

// ???????8X16     ??,??,???,C51???
// 0(0) 1(1) 2(2) 3(3) 4(4) 5(5) 6(6) 7(7) 8(8) 9(9) A(10) B(11) C(12) D(13) E(14) F(15) +(16) -(17) ".",18* " ",19*


void seclet(unsigned char num)
{
if(num<64)
{

	LCD_CS1=0;
	LCD_CS2=1;

}
else 
{

	LCD_CS1=1;
	LCD_CS2=0;

}

}
/*-------------------------------------------------------
????: Write_Com()
????: ?LCD12864??????
??    :Com  ?????
???  : ?
---------------------------------------------------------*/
void Write_Com(uchar com)
{
	LCD_RS=0;//??????
	LCD_RW=0;//???	
	Data_Port=com;  
	LCD_E=0;
	LCD_E=1; 
	LCD_E=0;
}
/*-------------------------------------------------------
????: Write_Data()
????: ?LCD12864??????
??    :Data  ?????
???  : ?
---------------------------------------------------------*/
void Write_Data(uchar Data)
{
	LCD_RS=1;//??????
	LCD_RW=0;//???	
	Data_Port=Data;  
	LCD_E=0;
	LCD_E=1;
	LCD_E=0;
}
/*-------------------------------------------------------
????: LCD12864_Init()
????: LCD12864???
??    : 
???  : ?
---------------------------------------------------------*/
void LCD12864_Init()
{
	Data_Port=0xFF;
	LCD_RST =0;  //12864??
	LCD_RST =1;  //12864???? 
	LCD_CS1=0;  //??????
	LCD_CS2=0;
	Write_Com(0x3e);//???
	Write_Com(0x3f);//???
	Write_Com(0xc0);//???????-0?
	Write_Com(0xb8);//??X?????-0?
	Write_Com(0x40);//??Y?????-0?
}
/*---------------------------------------------------
????: LCD12864_Clear()
????: ??
??:
LCD_CS1=0;LCD_CS2=0;???
LCD_CS1=0;LCD_CS2=1;???
LCD_CS1=1;LCD_CS2=0;???
???  :?
-----------------------------------------------------*/
void LCD12864_Clear()
{
	uchar aa,bb;//aa??X??,bb??Y???
			LCD_CS1=0;
			LCD_CS2=0;
		for(aa=0;aa<8;aa++)
		{
			Write_Com(0xb8+aa);

			for(bb=0;bb<64;bb++)
			{
				Write_Com(0x40+bb);
				Write_Data(0x00);
			}
		}
}
void LCD12864_Clear_(unsigned char x)
{
	uchar aa,bb;//aa??X??,bb??Y???
			LCD_CS1=0;
			LCD_CS2=0;
Write_Com(0xb8+x);
			for(bb=0;bb<64;bb++)
			{
				Write_Com(0x40+bb);
				Write_Data(0x00);
			}
}
/*-----------------------------------------
????: LCD12864_Disp()
????: ????(X,Y)???????
??    : X-????? ,Y-????? ,*P ??-??????
???  : ?
------------------------------------------*/
void LCD12864_Disp(uchar x, uchar y, uchar *p )
{

	uchar i;
	seclet(y);
	y=y%64;
	for(i=0;i<32;i++)
	{
		Write_Com(0xb8+x+i/16);     //����Xҳ��ַ
		Write_Com(0x40+y+i%16);   //����Y�˵�ַ
		Write_Data(p[i]);        //������
	}
}

/*-----------------------------------------
????: LCD12864_DispNum()
????: ????(X,Y)???????
??    : X-????? ,Y-????? ,*P ??-??????
???  : ?
------------------------------------------*/
void LCD12864_DispNum(uchar x, uchar y, uchar *p )
{

	uchar i;
	seclet(y);
	y=y%64;
	for(i=0;i<16;i++)
	{
		Write_Com(0xb8+x+i/8);     //����Xҳ��ַ
		Write_Com(0x40+y+i%8);   //����Y�˵�ַ
		Write_Data(p[i]);        //������
	}
}
